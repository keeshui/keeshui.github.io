# beginner-html-site-styled
A simple one page website created to help complete beginners learn HTML basics says MDN, which in this repo also is styled to help beginners like me learn CSS basics. The styling is explained over the course at Mozilla.
[Run this example live to help me](http://keeshui.github.io/).
